package com.hcpt.multileagues.interfaces;

import com.hcpt.multileagues.objects.MatchObj;

public interface OnNotificationButtonClickListener {
    void onNotificationButtonClick(MatchObj matchObj);
}
