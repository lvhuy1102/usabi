package com.hcpt.multileagues.objects;

import java.util.ArrayList;
import java.util.List;

public class RankGroupObject {
    private String groupId;
    private String groupName;
    private String mId, mLogo, mNameClubs, mP, mW, mD, mL, mGD, mPTS, manager, nickName, established,
            stadium, mClubUrl, group, position;
//    private Boolean setColor=false;

    public RankGroupObject(String groupId, String groupName, String mId, String mLogo, String mNameClubs, String mP, String mW, String mD,
                           String mL, String mGD, String mPTS, String manager, String nickName, String established,
                           String stadium, String mClubUrl, String group, String position) {
        this.groupId = groupId;
        this.groupName = groupName;
        this.mId = mId;
        this.mLogo = mLogo;
        this.mNameClubs = mNameClubs;
        this.mP = mP;
        this.mW = mW;
        this.mD = mD;
        this.mL = mL;
        this.mGD = mGD;
        this.mPTS = mPTS;
        this.manager = manager;
        this.nickName = nickName;
        this.established = established;
        this.stadium = stadium;
        this.mClubUrl = mClubUrl;
        this.group = group;
        this.position = position;
    }


    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getmId() {
        return mId;
    }

    public void setmId(String mId) {
        this.mId = mId;
    }

    public String getmLogo() {
        return mLogo;
    }

    public void setmLogo(String mLogo) {
        this.mLogo = mLogo;
    }

    public String getmNameClubs() {
        return mNameClubs;
    }

    public void setmNameClubs(String mNameClubs) {
        this.mNameClubs = mNameClubs;
    }

    public String getmP() {
        return mP;
    }

    public void setmP(String mP) {
        this.mP = mP;
    }

    public String getmW() {
        return mW;
    }

    public void setmW(String mW) {
        this.mW = mW;
    }

    public String getmD() {
        return mD;
    }

    public void setmD(String mD) {
        this.mD = mD;
    }

    public String getmL() {
        return mL;
    }

    public void setmL(String mL) {
        this.mL = mL;
    }

    public String getmGD() {
        return mGD;
    }

    public void setmGD(String mGD) {
        this.mGD = mGD;
    }

    public String getmPTS() {
        return mPTS;
    }

    public void setmPTS(String mPTS) {
        this.mPTS = mPTS;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getEstablished() {
        return established;
    }

    public void setEstablished(String established) {
        this.established = established;
    }

    public String getStadium() {
        return stadium;
    }

    public void setStadium(String stadium) {
        this.stadium = stadium;
    }

    public String getmClubUrl() {
        return mClubUrl;
    }

    public void setmClubUrl(String mClubUrl) {
        this.mClubUrl = mClubUrl;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
