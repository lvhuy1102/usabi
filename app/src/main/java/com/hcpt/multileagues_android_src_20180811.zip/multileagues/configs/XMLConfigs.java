package com.hcpt.multileagues.configs;

public class XMLConfigs {

	// Protocol
	public static final String PROTOCOL_HTTP = "http://";

	/*---------- Feeds ------------*/
	// Tags
	public static final String XML_TAG_ROOT = "channel";
	public static final String XML_TAG_ITEM = "item";
	public static final String XML_TAG_TITLE = "title";
	public static final String XML_TAG_LINK = "link";
	public static final String XML_TAG_IMAGE = "image";
	public static final String XML_TAG_ENCLOSURE = "enclosure";
	public static final String XML_TAG_IMG = "img";
	public static final String XML_TAG_PUBDATE = "pubDate";
	public static final String XML_TAG_DESCRIPTION = "description";

	// Attributes
	public static final String XML_ATTR_REL = "rel";
	public static final String XML_ATTR_HREF = "href";
	public static final String XML_ATTR_URL = "url";

	// Types
	public static final String XML_TYPE_ALTERNATE = "alternate";
}
