package com.hcpt.multileagues.configs;

/**
 * Created by NaPro on 01/02/2016.
 */
public class Args {

    public static final String KEY_UI_AUTO_REFRESH = "autoRefresh";
    public static final String KEY_UI_PROGRESS_VALUE = "progressValue";
    public static final String LANGUAGE = "language";
    public static final String SHOW_ODDS = "showOdds";
    public static final String BANNER_IMAGE = "bannerImage";
    public static final String BANNER_LINK = "bannerLink";
}
