package com.hcpt.multileagues.objects;

/**
 * Created by DoanKiem on 3/4/2016.
 */
public class AlarmMatch {
    private String matchId;
    private String matchTitle;
    private String time;
    private boolean onTime;
    private boolean before30Min;
    private boolean before60Min;
    private boolean before15Min;

    public AlarmMatch(String matchId, String matchTitle, String time, boolean onTime, boolean before30Min, boolean before60Min, boolean before15Min) {
        this.matchId=matchId;
        this.matchTitle = matchTitle;
        this.time = time;
        this.onTime = onTime;
        this.before30Min = before30Min;
        this.before60Min = before60Min;
        this.before15Min = before15Min;
    }

    public AlarmMatch() {
    }

    public String getMatchId() {
        return matchId;
    }

    public void setMatchId(String matchId) {
        this.matchId = matchId;
    }

    public String getMatchTitle() {
        return matchTitle;
    }

    public void setMatchTitle(String matchTitle) {
        this.matchTitle = matchTitle;
    }

    public boolean isBefore15Min() {
        return before15Min;
    }

    public void setBefore15Min(boolean before15Min) {
        this.before15Min = before15Min;
    }

    public boolean isBefore60Min() {
        return before60Min;
    }

    public void setBefore60Min(boolean before60Min) {
        this.before60Min = before60Min;
    }

    public boolean isBefore30Min() {
        return before30Min;
    }

    public void setBefore30Min(boolean before30Min) {
        this.before30Min = before30Min;
    }

    public boolean isOnTime() {
        return onTime;
    }

    public void setOnTime(boolean onTime) {
        this.onTime = onTime;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
