package com.hcpt.multileagues.database;

public final class DBKeyConfig {

	// TABLE :
	// ****************************************************************
	public static String TABLE_API = "Api";

	// *********** KEY FOR TABLE API **************
	public static String KEY_API_ID = "id";
	public static String KEY_API_API = "api";
	public static String KEY_API_RESULT = "result";

}
