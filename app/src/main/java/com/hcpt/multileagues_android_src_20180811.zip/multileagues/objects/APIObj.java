package com.hcpt.multileagues.objects;

public class APIObj {

	private String mId, mApi, mResult;

	public APIObj() {
		// TODO Auto-generated constructor stub
	}

	public APIObj(String id, String api, String result) {
		this.mId = id;
		this.mApi = api;
		this.mResult = result;
	}

	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}

	public String getmApi() {
		return mApi;
	}

	public void setmApi(String mApi) {
		this.mApi = mApi;
	}

	public String getmResult() {
		return mResult;
	}

	public void setmResult(String mResult) {
		this.mResult = mResult;
	}
}
