package com.hcpt.multileagues.objects;

/**
 * Created by NaPro on 12/29/2015.
 */
public class RoundObj {

    private String id, name;
    private boolean isCurrent;

    public RoundObj(String id, String name, boolean isCurrent) {
        this.id = id;
        this.name = name;
        this.isCurrent = isCurrent;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isCurrent() {
        return isCurrent;
    }

    public void setIsCurrent(boolean isCurrent) {
        this.isCurrent = isCurrent;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
