package com.hcpt.multileagues.objects;

public class TopScorerObj {

    private String mId, mPlayer, mScore, mClub;

    public TopScorerObj(String id, String player, String score, String club) {
        this.mId = id;
        this.mPlayer = player;
        this.mScore = score;
        this.mClub = club;
    }

    public String getmId() {
        return mId;
    }

    public void setmId(String mId) {
        this.mId = mId;
    }

    public String getmPlayer() {
        return mPlayer;
    }

    public void setmPlayer(String mPlayer) {
        this.mPlayer = mPlayer;
    }

    public String getmScore() {
        return mScore;
    }

    public void setmScore(String mScore) {
        this.mScore = mScore;
    }

    public String getmClub() {
        return mClub;
    }

    public void setmClub(String mClub) {
        this.mClub = mClub;
    }
}
