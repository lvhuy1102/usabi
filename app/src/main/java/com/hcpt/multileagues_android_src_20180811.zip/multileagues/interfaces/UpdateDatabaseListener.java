package com.hcpt.multileagues.interfaces;

/**
 * Created by DoanKiem on 3/8/2016.
 */
public interface UpdateDatabaseListener {
    public void changeDatabaseListener();
}
