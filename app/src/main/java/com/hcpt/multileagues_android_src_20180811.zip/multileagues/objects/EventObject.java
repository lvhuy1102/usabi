package com.hcpt.multileagues.objects;

public class EventObject {

	private String mId, mMatchId, mPlayer, mClubId, mMinute, mIsScore,
			mEventType, mScores;

	public EventObject(String id, String matchId, String player, String clubId,
			String minute, String isScore, String eventType, String scores) {
		this.mId = id;
		this.mMatchId = matchId;
		this.mPlayer = player;
		this.mClubId = clubId;
		this.mMinute = minute;
		this.mIsScore = isScore;
		this.mEventType = eventType;
		this.mScores = scores;
	}

	public String getmScores() {
		return mScores;
	}

	public void setmScores(String mScores) {
		this.mScores = mScores;
	}

	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}

	public String getmMatchId() {
		return mMatchId;
	}

	public void setmMatchId(String mMatchId) {
		this.mMatchId = mMatchId;
	}

	public String getmPlayer() {
		return mPlayer;
	}

	public void setmPlayer(String mPlayer) {
		this.mPlayer = mPlayer;
	}

	public String getmClubId() {
		return mClubId;
	}

	public void setmClubId(String mClubId) {
		this.mClubId = mClubId;
	}

	public String getmMinute() {
		return mMinute;
	}

	public void setmMinute(String mMinute) {
		this.mMinute = mMinute;
	}

	public String getmIsScore() {
		return mIsScore;
	}

	public void setmIsScore(String mIsScore) {
		this.mIsScore = mIsScore;
	}

	public String getmEventType() {
		return mEventType;
	}

	public void setmEventType(String mEventType) {
		this.mEventType = mEventType;
	}

}
