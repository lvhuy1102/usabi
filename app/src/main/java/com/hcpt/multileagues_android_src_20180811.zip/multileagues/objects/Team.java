package com.hcpt.multileagues.objects;

import java.io.Serializable;

/**
 * Created by DOAN KIEM on 21/01/2016.
 */
public class Team implements Serializable {
    private String id;
    private String name;
    private String linkFlag;
    private String teamCode;
    private int idImage; //for load image from device
    private int idNameString;

    public int getIdImage() {
        return idImage;
    }

    public void setIdImage(int idImage) {
        this.idImage = idImage;
    }

    public int getIdNameString() {
        return idNameString;
    }

    public void setIdNameString(int idNameString) {
        this.idNameString = idNameString;
    }

    public Team() {
    }

    public Team(String id, String name, String teamCode, String linkFlag) {
        this.id=id;
        this.name = name;
        this.teamCode = teamCode;
        this.linkFlag = linkFlag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLinkFlag() {
        return linkFlag;
    }

    public void setLinkFlag(String linkFlag) {
        this.linkFlag = linkFlag;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }
}
