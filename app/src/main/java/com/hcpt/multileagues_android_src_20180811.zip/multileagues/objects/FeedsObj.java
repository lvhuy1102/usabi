package com.hcpt.multileagues.objects;

public class FeedsObj {

    private String mNewsTitle, mDescription, mPubDate, mLinkNews, mUriImg;

    public FeedsObj(String newsTitle, String mDescription, String imgNews, String link,
                    String pubDate) {
        this.mUriImg = imgNews;
        this.mNewsTitle = newsTitle;
        this.mLinkNews = link;
        this.mDescription = mDescription;
        this.mPubDate = pubDate;
    }

    public FeedsObj() {
    }

    public String getmNewsTitle() {
        return mNewsTitle;
    }

    public String getmDescription() {
        return mDescription;
    }

    public void setmDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public void setmNewsTitle(String mNewsTitle) {
        this.mNewsTitle = mNewsTitle;
    }

    public String getmPubDate() {
        return mPubDate;
    }

    public void setmPubDate(String mPubDate) {
        this.mPubDate = mPubDate;
    }

    public String getmLinkNews() {
        return mLinkNews;
    }

    public void setmLinkNews(String mLinkNews) {
        this.mLinkNews = mLinkNews;
    }

    public String getmUriImg() {
        return mUriImg;
    }

    public void setmUriImg(String mUriImg) {
        this.mUriImg = mUriImg;
    }
}
