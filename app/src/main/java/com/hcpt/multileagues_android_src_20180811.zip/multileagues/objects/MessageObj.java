package com.hcpt.multileagues.objects;

/**
 * Created by GL62 on 7/5/2017.
 */

public class MessageObj {
    private String userID;
    private String userName;
    private String content;
    private String datepost;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDatepost() {
        return datepost;
    }

    public void setDatepost(String datepost) {
        this.datepost = datepost;
    }
}
