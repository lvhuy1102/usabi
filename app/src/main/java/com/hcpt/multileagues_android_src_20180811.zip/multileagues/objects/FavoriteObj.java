package com.hcpt.multileagues.objects;

/**
 * Created by NaPro on 01/02/2016.
 */
public class FavoriteObj {

    private String id, name;
    private boolean isFav;

    public FavoriteObj(String id, String name, boolean isFav) {
        this.id = id;
        this.name = name;
        this.isFav = isFav;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isFav() {
        return isFav;
    }

    public void setIsFav(boolean isFav) {
        this.isFav = isFav;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
