package com.hcpt.multileagues.interfaces;

import android.view.View;

/**
 * Created by DoanKiem on 3/29/2016.
 */
public interface ItemRecycleViewTouchListener {
    public void recyclerViewListClicked(View v, int position);
}
