package com.hcpt.multileagues.modelmanager;

public interface ModelManagerListener {

	public void onError();

	public void onSuccess(Object object);
}
