package com.hcpt.multileagues.Listener;

/**
 * Created by GL62 on 7/6/2017.
 */

public class AdapterListener {
    public interface MessageAdapterListener {
        void setListtoBottom(int postion);
    }

}
